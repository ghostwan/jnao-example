var searchData=
[
  ['globalposition',['globalPosition',['../classSim_1_1Frame.html#a50b7ebe1adee8186c1264a5b890c192d',1,'Sim::Frame']]],
  ['groups',['groups',['../classSim_1_1LEDActuator.html#a932c0c863f45163c026ce9c94d63e4ae',1,'Sim::LEDActuator']]]
];
