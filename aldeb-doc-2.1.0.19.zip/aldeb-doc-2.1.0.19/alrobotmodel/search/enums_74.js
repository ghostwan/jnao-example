var searchData=
[
  ['type',['Type',['../classSim_1_1Actuator.html#a9e218acaf5f202a77e71b53ba5223e27',1,'Sim::Actuator::Type()'],['../classSim_1_1Sensor.html#a7827135d79637a0b67e4a025b87e201b',1,'Sim::Sensor::Type()']]]
];
